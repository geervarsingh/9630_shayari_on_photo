 package bhobhli.shayarimaker.shayarionphoto;

 import static android.graphics.Color.CYAN;
 import static android.graphics.Color.RED;
 import static android.graphics.Color.WHITE;

 import android.Manifest;
 import android.app.Activity;
 import android.app.Dialog;
 import android.content.ActivityNotFoundException;
 import android.content.ContentResolver;
 import android.content.ContentValues;
 import android.content.DialogInterface;
 import android.content.Intent;
 import android.content.pm.PackageManager;
 import android.graphics.Bitmap;
 import android.graphics.Canvas;
 import android.graphics.Color;
 import android.graphics.Typeface;
 import android.net.Uri;
 import android.os.Build;
 import android.os.Bundle;
 import android.os.Environment;
 import android.os.Handler;
 import android.os.StrictMode;
 import android.provider.MediaStore;
 import android.view.LayoutInflater;
 import android.view.View;
 import android.widget.Button;
 import android.widget.EditText;
 import android.widget.ImageView;
 import android.widget.RelativeLayout;
 import android.widget.TextView;
 import android.widget.Toast;

 import androidx.annotation.Nullable;
 import androidx.appcompat.app.AlertDialog;
 import androidx.appcompat.app.AppCompatActivity;
 import androidx.cardview.widget.CardView;
 import androidx.constraintlayout.widget.ConstraintLayout;
 import androidx.core.app.ActivityCompat;
 import androidx.core.content.ContextCompat;

 import com.unity3d.ads.UnityAds;
 import com.unity3d.services.banners.BannerView;
 import com.unity3d.services.banners.UnityBannerSize;

 import java.io.File;
 import java.io.FileNotFoundException;
 import java.io.FileOutputStream;
 import java.io.IOException;
 import java.io.OutputStream;
 import java.util.Objects;

 import de.hdodenhof.circleimageview.CircleImageView;
 import pl.droidsonroids.gif.GifImageView;

 public class Twelve extends AppCompatActivity {
     String GAMEID="44252";
     String BANNERID="Banner_Android";
     String INTERSTITIALID="Interstitial_Android";
     boolean  test=false;
     RelativeLayout bannerAd;
     OutputStream outputStream;
     public int STORAGE_PERMISSION_CODE = 1;

     ConstraintLayout text_sub_menu,add_brandname_layout,inner_layout,ss;
     CardView open_gallery,circle_logo_click,add_text,add_brand_text,text_color,brand_color,text_color_layout,brand_color_layout,background_color,bgColorLayout,
             text_size_layout,text_size,fonts_layout,text_style,brand_style,brand_size,saveImage;
     CardView con1,con2;
     ////////Color Card View////////////
     CardView red, blue, green, black, white, yellow, silver, magenta, cyan;
     ////////Brand Color Card View////////////
     CardView red_brand, blue_brand, green_brand, black_brand, white_brand, yellow_brand, silver_brand, magenta_brand, cyan_brand;

     ////////////////BackgroundColor//////////////////
     CardView bg_red, bg_blue, bg_green, bg_black, bg_white, bg_yellow, bg_silver, bg_magenta, bg_cyan, bg_default;
     ////////////////BackgroundColor//////////////////
     //////////////Text Size//////////////////////////
     TextView eleven,thirteen,fifteen, seventeen, nineteen, twentyone, twentythree, twentyfive, twentyseven, twentynine, thirtyone, thirtythree, thirtyfive, fourty, fifty, fiftyfive, sixty;
     //////////////Text Size//////////////////////////
     //////////Text Style//////////////
     CardView alloy, bigfat, branda, chrusty, freedom, gingies, plastic, quite, tothepoint, vampire,
             batik, black_widow, heleny, lemon, pinky, resote;
     //////////hindi text////////
     CardView hindi1,hindi2,hindi3,hindi4,hindi5,hindi6,hindi7,hindi8,hindi9,hindi10,hindi11,hindi12;
     //////////Text Style//////////////
     TextView blur_red,blur_blue,blur_green,blur_black,blur_white,blur_yellow,blur_silver,blur_magenta,blur_cyan;
     ImageView showImage,tom;
     EditText editText,editText_brandname;
     TextView showText,showBrandName,blur;
     CircleImageView circle_logo;
     Uri imageUri;
     Uri imageUri2;
     Button addTextButton,addTextButton_brandname;
     GifImageView openQurekaGif;

     @Override
     protected void onCreate(Bundle savedInstanceState) {
         super.onCreate(savedInstanceState);
         setContentView(R.layout.activity_twelve);
         UnityAds.initialize(this,GAMEID,test);

         openQurekaGif=findViewById(R.id.open_qureka);
         openQurekaGif.setOnClickListener(v -> {
            exitButtonPressed();
         });
         bannerAd=findViewById(R.id.bannerAd);
         BannerView view1=new BannerView(this,BANNERID,new UnityBannerSize(320,50));
         view1.load();
         bannerAd.addView(view1);

         open_gallery = findViewById(R.id.open_gallery);
         showImage = (ImageView) findViewById(R.id.showImage);
         circle_logo = findViewById(R.id.circle_logo);
         circle_logo_click = findViewById(R.id.circle_logo_click);
         add_text = findViewById(R.id.add_text);
         add_brand_text = findViewById(R.id.add_brand_text);
         text_sub_menu = findViewById(R.id.add_text_layout);
         add_brandname_layout = findViewById(R.id.add_brandname_layout);
         inner_layout = findViewById(R.id.inner_layout);
         addTextButton = findViewById(R.id.addTextButton);
         addTextButton_brandname = findViewById(R.id.addTextButton_brandname);
         editText = findViewById(R.id.editText);
         editText_brandname = findViewById(R.id.editText_brandname);
         showText = findViewById(R.id.showText);
         showBrandName = findViewById(R.id.show_brand_name);
         blur = findViewById(R.id.blur);
         text_color = findViewById(R.id.text_color);
         brand_color = findViewById(R.id.brand_color);
         text_color_layout = findViewById(R.id.text_color_layout);
         brand_color_layout = findViewById(R.id.brand_color_layout);
         background_color = findViewById(R.id.background_color);
         bgColorLayout = findViewById(R.id.bg_color_layout);
         text_size_layout = findViewById(R.id.text_size_layout);
         text_size = findViewById(R.id.text_size);
         text_style = findViewById(R.id.text_style);
         brand_style = findViewById(R.id.brand_style);
         brand_size=findViewById(R.id.brand_size);
         fonts_layout = findViewById(R.id.fonts_layout);
         saveImage =findViewById(R.id.imageSave);
         con1=findViewById(R.id.con1);
         con2=findViewById(R.id.con2);

         blur_red=findViewById(R.id.blur_red);
         blur_blue=findViewById(R.id.blur_blue);
         blur_green=findViewById(R.id.blur_green);
         blur_black=findViewById(R.id.blur_black);
         blur_white=findViewById(R.id.blur_white);
         blur_yellow=findViewById(R.id.blur_yellow);
         blur_silver=findViewById(R.id.blur_silver);
         blur_magenta=findViewById(R.id.blur_magenta);
         blur_cyan=findViewById(R.id.blur_cyan);

         addBackgroundImage();
         addCircleLogo();
         addText();
         addBrandText();
         addTextButton();
         addTextButton_brandname();
         textColor();
         brandColor();
         backgroundColor();
         textSize();
         textStyle();
         brandStyle();
         brandSize();
         StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
         StrictMode.setVmPolicy(builder.build());

         saveImage.setOnClickListener(v -> {
           saveImageToGallery();
             loadInterStitial();
             if (UnityAds.isReady(INTERSTITIALID)){
                 UnityAds.show(this,INTERSTITIALID);
             }
         });
     }
     private void loadInterStitial() {
         if (UnityAds.isInitialized()){
             UnityAds.load(INTERSTITIALID);
         }
         else {
             new Handler().postDelayed(new Runnable() {
                 @Override
                 public void run() {
                     UnityAds.load(INTERSTITIALID);
                 }
             },3000);
         }
     }
     public void saveImageToGallery() {
         if (ContextCompat.checkSelfPermission(Twelve.this,
                 Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
             Bitmap bitmap = Bitmap.createBitmap(Twelve.this.con1.getWidth(), Twelve.this.con1.getHeight(),Bitmap.Config.ARGB_8888);

             Canvas canvas = new Canvas(bitmap);
             Twelve.this.con1.draw(canvas);
             OutputStream fos;

             if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                 ContentResolver resolver = this.getContentResolver();
                 ContentValues contentValues = new ContentValues();
                 contentValues.put(MediaStore.MediaColumns.DISPLAY_NAME, System.currentTimeMillis() + ".jpg");
                 contentValues.put(MediaStore.MediaColumns.MIME_TYPE, "image/jpg");
                 contentValues.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES);
                 Uri imageUri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues);

                 Toast.makeText(this, "Image Saved in Pictures.", Toast.LENGTH_LONG).show();

                 try {
                     fos = resolver.openOutputStream(Objects.requireNonNull(imageUri));
                     bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fos);

                     fos.flush();
                     fos.close();
                 } catch (FileNotFoundException e) {
                     e.printStackTrace();
                 } catch (IOException e) {
                     e.printStackTrace();
                 }
             } else {
                 FileOutputStream outputStream = null;
                 File sdCard = Environment.getExternalStorageDirectory();
                 File directory = new File(sdCard.getAbsolutePath() + "InstaGram Temp");
                 directory.mkdir();
                 String filename = String.format("%d.jpg", System.currentTimeMillis());
                 File outFile = new File(directory, filename);
                 Toast.makeText(this, "Image Saved in Pictures.", Toast.LENGTH_SHORT).show();

                 try {
                     outputStream = new FileOutputStream(outFile);
                     bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream);

                     outputStream.flush();
                     outputStream.close();

                     Intent intent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
                     intent.setData(Uri.fromFile(outFile));
                     this.sendBroadcast(intent);
                 } catch (FileNotFoundException e) {
                     e.printStackTrace();
                 } catch (IOException e) {
                     e.printStackTrace();
                 }

             }
         }else{
             //show permission popup
             requestStoragePermission();
         }
     }
     ///////////storage permission/////
     public void requestStoragePermission(){
         if (ActivityCompat.shouldShowRequestPermissionRationale((Activity)this,Manifest.permission.READ_EXTERNAL_STORAGE)){

             new AlertDialog.Builder(this)
                     .setTitle("Permission needed")
                     .setMessage("This permission is needed")
                     .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                         @Override
                         public void onClick(DialogInterface dialog, int which) {
                             ActivityCompat.requestPermissions((Activity) Twelve.this,new String[] {Manifest.permission.READ_EXTERNAL_STORAGE},STORAGE_PERMISSION_CODE);
                         }
                     })
                     .setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                         @Override
                         public void onClick(DialogInterface dialog, int which) {
                             dialog.dismiss();
                         }
                     }).create().show();

         }else {
             ActivityCompat.requestPermissions((Activity) Twelve.this,new String[] {Manifest.permission.READ_EXTERNAL_STORAGE},STORAGE_PERMISSION_CODE);
         }
     }

     public void textStyle() {
         text_style.setOnClickListener(v -> {

             text_style.setCardBackgroundColor(CYAN);
             brand_size.setCardBackgroundColor(WHITE);
             brand_style.setCardBackgroundColor(WHITE);
             text_color.setCardBackgroundColor(WHITE);
             text_size.setCardBackgroundColor(WHITE);
             brand_color.setCardBackgroundColor(WHITE);
             background_color.setCardBackgroundColor(WHITE);

             fonts_layout.setVisibility(View.VISIBLE);
             text_size_layout.setVisibility(View.INVISIBLE);
             bgColorLayout.setVisibility(View.INVISIBLE);
             text_color_layout.setVisibility(View.INVISIBLE);
             text_sub_menu.setVisibility(View.GONE);
             ////Text Style/////////

             hindi1=findViewById(R.id.hindi_one);
             hindi1.setOnClickListener(v1 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "hindi_biryani.ttf");
                     showText.setTypeface(typeface);
                 }
                 catch (Exception e){}
             });
             hindi2=findViewById(R.id.hindi_two);
             hindi2.setOnClickListener(v1 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "hindi_amiko.ttf");
                     showText.setTypeface(typeface);
                 }
                 catch (Exception e){}
             });
             hindi3=findViewById(R.id.hindi_three);
             hindi3.setOnClickListener(v1 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "hindi_arya.ttf");
                     showText.setTypeface(typeface);
                 }
                 catch (Exception e){}
             });
             hindi4=findViewById(R.id.hindi_four);
             hindi4.setOnClickListener(v1 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "hindi_gist.ttf");
                     showText.setTypeface(typeface);
                 }
                 catch (Exception e){}
             });
             hindi5=findViewById(R.id.hindi_five);
             hindi5.setOnClickListener(v1 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "hindi_modak.ttf");
                     showText.setTypeface(typeface);
                 }
                 catch (Exception e){}
             });
             hindi6=findViewById(R.id.hindi_six);
             hindi6.setOnClickListener(v1 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "hindi_regular.ttf");
                     showText.setTypeface(typeface);
                 }
                 catch (Exception e){}
             });
             hindi7=findViewById(R.id.hindi_seven);
             hindi7.setOnClickListener(v1 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "hindi_rojha.ttf");
                     showText.setTypeface(typeface);
                 }
                 catch (Exception e){}
             });
             hindi8=findViewById(R.id.hindi_eight);
             hindi8.setOnClickListener(v1 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "hindi_sahadeva.ttf");
                     showText.setTypeface(typeface);
                 }
                 catch (Exception e){}
             });
             hindi9=findViewById(R.id.hindi_nine);
             hindi9.setOnClickListener(v1 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "hindi_samyak.ttf");
                     showText.setTypeface(typeface);
                 }
                 catch (Exception e){}
             });
             hindi10=findViewById(R.id.hindi_ten);
             hindi10.setOnClickListener(v1 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "hindi_sarala.ttf");
                     showText.setTypeface(typeface);
                 }
                 catch (Exception e){}
             });
             hindi11=findViewById(R.id.hindi_eleven);
             hindi11.setOnClickListener(v1 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "hindi_teko.ttf");
                     showText.setTypeface(typeface);
                 }
                 catch (Exception e){}
             });
             hindi12=findViewById(R.id.hindi_twelve);
             hindi12.setOnClickListener(v1 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "hindi_yatra.ttf");
                     showText.setTypeface(typeface);
                 }
                 catch (Exception e){}
             });

             batik = findViewById(R.id.font_batik);
             batik.setOnClickListener(v1 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "batik.otf");
                     showText.setTypeface(typeface);
                 }
                 catch (Exception e){}

             });
             black_widow = findViewById(R.id.font_black_widow);
             black_widow.setOnClickListener(v1 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "black_widow.ttf");
                     showText.setTypeface(typeface);
                 }
                 catch (Exception e){}

             });
             heleny = findViewById(R.id.font_heleny);
             heleny.setOnClickListener(v1 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "heleny.ttf");
                     showText.setTypeface(typeface);
                 }
                 catch (Exception e){}

             });
             lemon = findViewById(R.id.font_lemon);
             lemon.setOnClickListener(v1 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "lemon.ttf");
                     showText.setTypeface(typeface);
                 }
                 catch (Exception e){}

             });
             pinky = findViewById(R.id.font_pinky);
             pinky.setOnClickListener(v1 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "pinky.ttf");
                     showText.setTypeface(typeface);
                 }
                 catch (Exception e){}

             });
             resote = findViewById(R.id.font_resote);
             resote.setOnClickListener(v1 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "resote.ttf");
                     showText.setTypeface(typeface);
                 }
                 catch (Exception e){}

             });

             CardView default_font;
             default_font = findViewById(R.id.default_font);
             default_font.setOnClickListener(v1 -> {
                 try {
                     Typeface typeface = Typeface.DEFAULT;
                     showText.setTypeface(typeface);
                 }
                 catch (Exception e){}

             });

             alloy = findViewById(R.id.font_alloyink);
             alloy.setOnClickListener(v2 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "alloy.ttf");
                     showText.setTypeface(typeface);
                 }
                 catch (Exception e){}

             });
             bigfat = findViewById(R.id.font_bigfat);
             bigfat.setOnClickListener(v2 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "bigfat.ttf");
                     showText.setTypeface(typeface);
                 }
                 catch (Exception e){}

             });
             chrusty = findViewById(R.id.font_chrusty);
             chrusty.setOnClickListener(v2 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "chrusty.ttf");
                     showText.setTypeface(typeface);
                 }
                 catch (Exception e){}

             });
             branda = findViewById(R.id.font_branda);
             branda.setOnClickListener(v2 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "branda.ttf");
                     showText.setTypeface(typeface);
                 }
                 catch (Exception e){}

             });
             freedom = findViewById(R.id.font_freedom);
             freedom.setOnClickListener(v2 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "freedom.ttf");
                     showText.setTypeface(typeface);
                 }
                 catch (Exception e){}

             });

             gingies = findViewById(R.id.font_gingies);
             gingies.setOnClickListener(v2 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "gingies.otf");
                     showText.setTypeface(typeface);
                 }
                 catch (Exception e){}

             });
             plastic = findViewById(R.id.font_plastic);
             plastic.setOnClickListener(v2 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "plastic.ttf");
                     showText.setTypeface(typeface);
                 }
                 catch (Exception e){}

             });
             quite = findViewById(R.id.font_quite);
             quite.setOnClickListener(v2 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "quite.ttf");
                     showText.setTypeface(typeface);
                 }
                 catch (Exception e){}

             });
             tothepoint = findViewById(R.id.font_tothepoint);
             tothepoint.setOnClickListener(v2 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "tothepoint.ttf");
                     showText.setTypeface(typeface);
                 }
                 catch (Exception e){}

             });
             vampire = findViewById(R.id.font_vampire);
             vampire.setOnClickListener(v2 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "vampire.ttf");
                     showText.setTypeface(typeface);
                 }
                 catch (Exception e){}

             });
         });
     }
     public void brandStyle() {
         brand_style.setOnClickListener(v -> {
             brand_style.setCardBackgroundColor(CYAN);
             brand_size.setCardBackgroundColor(WHITE);
             text_style.setCardBackgroundColor(WHITE);
             text_color.setCardBackgroundColor(WHITE);
             text_size.setCardBackgroundColor(WHITE);
             brand_color.setCardBackgroundColor(WHITE);
             background_color.setCardBackgroundColor(WHITE);

             fonts_layout.setVisibility(View.VISIBLE);
             text_size_layout.setVisibility(View.INVISIBLE);
             bgColorLayout.setVisibility(View.INVISIBLE);
             text_color_layout.setVisibility(View.INVISIBLE);
             text_sub_menu.setVisibility(View.GONE);
             ////Text Style/////////

             hindi1=findViewById(R.id.hindi_one);
             hindi1.setOnClickListener(v1 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "hindi_biryani.ttf");
                     showBrandName.setTypeface(typeface);
                 }
                 catch (Exception e){}
             });
             hindi2=findViewById(R.id.hindi_two);
             hindi2.setOnClickListener(v1 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "hindi_amiko.ttf");
                     showBrandName.setTypeface(typeface);
                 }
                 catch (Exception e){}
             });
             hindi3=findViewById(R.id.hindi_three);
             hindi3.setOnClickListener(v1 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "hindi_arya.ttf");
                     showBrandName.setTypeface(typeface);
                 }
                 catch (Exception e){}
             });
             hindi4=findViewById(R.id.hindi_four);
             hindi4.setOnClickListener(v1 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "hindi_gist.ttf");
                     showBrandName.setTypeface(typeface);
                 }
                 catch (Exception e){}
             });
             hindi5=findViewById(R.id.hindi_five);
             hindi5.setOnClickListener(v1 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "hindi_modak.ttf");
                     showBrandName.setTypeface(typeface);
                 }
                 catch (Exception e){}
             });
             hindi6=findViewById(R.id.hindi_six);
             hindi6.setOnClickListener(v1 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "hindi_regular.ttf");
                     showBrandName.setTypeface(typeface);
                 }
                 catch (Exception e){}
             });
             hindi7=findViewById(R.id.hindi_seven);
             hindi7.setOnClickListener(v1 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "hindi_rojha.ttf");
                     showBrandName.setTypeface(typeface);
                 }
                 catch (Exception e){}
             });
             hindi8=findViewById(R.id.hindi_eight);
             hindi8.setOnClickListener(v1 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "hindi_sahadeva.ttf");
                     showBrandName.setTypeface(typeface);
                 }
                 catch (Exception e){}
             });
             hindi9=findViewById(R.id.hindi_nine);
             hindi9.setOnClickListener(v1 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "hindi_samyak.ttf");
                     showBrandName.setTypeface(typeface);
                 }
                 catch (Exception e){}
             });
             hindi10=findViewById(R.id.hindi_ten);
             hindi10.setOnClickListener(v1 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "hindi_sarala.ttf");
                     showBrandName.setTypeface(typeface);
                 }
                 catch (Exception e){}
             });
             hindi11=findViewById(R.id.hindi_eleven);
             hindi11.setOnClickListener(v1 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "hindi_teko.ttf");
                     showBrandName.setTypeface(typeface);
                 }
                 catch (Exception e){}
             });
             hindi12=findViewById(R.id.hindi_twelve);
             hindi12.setOnClickListener(v1 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "hindi_yatra.ttf");
                     showBrandName.setTypeface(typeface);
                 }
                 catch (Exception e){}
             });

             batik = findViewById(R.id.font_batik);
             batik.setOnClickListener(v1 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "batik.otf");
                     showBrandName.setTypeface(typeface);
                 }
                 catch (Exception e){}

             });
             black_widow = findViewById(R.id.font_black_widow);
             black_widow.setOnClickListener(v1 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "black_widow.ttf");
                     showBrandName.setTypeface(typeface);
                 }
                 catch (Exception e){}

             });
             heleny = findViewById(R.id.font_heleny);
             heleny.setOnClickListener(v1 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "heleny.ttf");
                     showBrandName.setTypeface(typeface);
                 }
                 catch (Exception e){}

             });
             lemon = findViewById(R.id.font_lemon);
             lemon.setOnClickListener(v1 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "lemon.ttf");
                     showBrandName.setTypeface(typeface);
                 }
                 catch (Exception e){}

             });
             pinky = findViewById(R.id.font_pinky);
             pinky.setOnClickListener(v1 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "pinky.ttf");
                     showBrandName.setTypeface(typeface);
                 }
                 catch (Exception e){}

             });
             resote = findViewById(R.id.font_resote);
             resote.setOnClickListener(v1 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "resote.ttf");
                     showBrandName.setTypeface(typeface);
                 }
                 catch (Exception e){}

             });

             CardView default_font;
             default_font = findViewById(R.id.default_font);
             default_font.setOnClickListener(v1 -> {
                 try {
                     Typeface typeface = Typeface.DEFAULT;
                     showBrandName.setTypeface(typeface);
                 }
                 catch (Exception e){}

             });

             alloy = findViewById(R.id.font_alloyink);
             alloy.setOnClickListener(v2 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "alloy.ttf");
                     showBrandName.setTypeface(typeface);
                 }
                 catch (Exception e){}

             });
             bigfat = findViewById(R.id.font_bigfat);
             bigfat.setOnClickListener(v2 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "bigfat.ttf");
                     showBrandName.setTypeface(typeface);
                 }
                 catch (Exception e){}

             });
             chrusty = findViewById(R.id.font_chrusty);
             chrusty.setOnClickListener(v2 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "chrusty.ttf");
                     showBrandName.setTypeface(typeface);
                 }
                 catch (Exception e){}

             });
             branda = findViewById(R.id.font_branda);
             branda.setOnClickListener(v2 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "branda.ttf");
                     showBrandName.setTypeface(typeface);
                 }
                 catch (Exception e){}

             });
             freedom = findViewById(R.id.font_freedom);
             freedom.setOnClickListener(v2 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "freedom.ttf");
                     showBrandName.setTypeface(typeface);
                 }
                 catch (Exception e){}

             });

             gingies = findViewById(R.id.font_gingies);
             gingies.setOnClickListener(v2 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "gingies.otf");
                     showBrandName.setTypeface(typeface);
                 }
                 catch (Exception e){}

             });
             plastic = findViewById(R.id.font_plastic);
             plastic.setOnClickListener(v2 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "plastic.ttf");
                     showBrandName.setTypeface(typeface);
                 }
                 catch (Exception e){}

             });
             quite = findViewById(R.id.font_quite);
             quite.setOnClickListener(v2 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "quite.ttf");
                     showBrandName.setTypeface(typeface);
                 }
                 catch (Exception e){}

             });
             tothepoint = findViewById(R.id.font_tothepoint);
             tothepoint.setOnClickListener(v2 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "tothepoint.ttf");
                     showBrandName.setTypeface(typeface);
                 }
                 catch (Exception e){}

             });
             vampire = findViewById(R.id.font_vampire);
             vampire.setOnClickListener(v2 -> {
                 try {
                     Typeface typeface = Typeface.createFromAsset(getAssets(), "vampire.ttf");
                     showBrandName.setTypeface(typeface);
                 }
                 catch (Exception e){}

             });
         });
     }
     public void textSize() {
         text_size.setOnClickListener(v -> {
             text_size.setCardBackgroundColor(CYAN);
             brand_size.setCardBackgroundColor(WHITE);
             brand_style.setCardBackgroundColor(WHITE);
             text_style.setCardBackgroundColor(WHITE);
             brand_color.setCardBackgroundColor(WHITE);
             text_color.setCardBackgroundColor(WHITE);
             background_color.setCardBackgroundColor(WHITE);

             text_size_layout.setVisibility(View.VISIBLE);
             bgColorLayout.setVisibility(View.INVISIBLE);
             text_color_layout.setVisibility(View.INVISIBLE);
             text_sub_menu.setVisibility(View.GONE);
             fonts_layout.setVisibility(View.INVISIBLE);

             ///////Text Size//////////////
             ///////Text Size//////////////

             eleven = findViewById(R.id.eleven);
             eleven.setOnClickListener(view -> {
                 try {
                     showText.setTextSize(11);
                 }catch (Exception e){}

             });
             thirteen = findViewById(R.id.thirteen);
             thirteen.setOnClickListener(view -> {
                 try {
                     showText.setTextSize(13);
                 }catch (Exception e){}

             });
             fifteen = findViewById(R.id.fifteen);
             fifteen.setOnClickListener(view -> {
                 try {
                     showText.setTextSize(15);
                 }catch (Exception e){}

             });


             seventeen = findViewById(R.id.seventeen);
             seventeen.setOnClickListener(view -> {
                 try {
                     showText.setTextSize(17);
                 }catch (Exception e){}

             });
             nineteen = findViewById(R.id.nineteen);
             nineteen.setOnClickListener(view -> {
                 try {
                     showText.setTextSize(19);
                 }catch (Exception e){}

             });
             twentyone = findViewById(R.id.twentyone);
             twentyone.setOnClickListener(view -> {
                 try {
                     showText.setTextSize(21);
                 }catch (Exception e){}

             });
             twentythree = findViewById(R.id.twentythree);
             twentythree.setOnClickListener(view -> {
                 try {
                     showText.setTextSize(23);
                 }catch (Exception e){}

             });
             twentyfive = findViewById(R.id.twentyfive);
             twentyfive.setOnClickListener(view -> {
                 try {
                     showText.setTextSize(25);
                 }catch (Exception e){}

             });
             twentyseven = findViewById(R.id.twentyseven);
             twentyseven.setOnClickListener(view -> {
                 try {
                     showText.setTextSize(27);
                 }catch (Exception e){}

             });
             twentynine = findViewById(R.id.twentynine);
             twentynine.setOnClickListener(view -> {
                 try {
                     showText.setTextSize(29);
                 }catch (Exception e){}

             });
             thirtyone = findViewById(R.id.thirtyone);
             thirtyone.setOnClickListener(view -> {
                 try {
                     showText.setTextSize(31);
                 }catch (Exception e){}

             });
             thirtythree = findViewById(R.id.thirtythree);
             thirtythree.setOnClickListener(view -> {
                 try {
                     showText.setTextSize(33);
                 }catch (Exception e){}

             });
             thirtyfive = findViewById(R.id.thirtyfive);
             thirtyfive.setOnClickListener(view -> {
                 try {
                     showText.setTextSize(35);
                 }catch (Exception e){}

             });
             fourty = findViewById(R.id.fourty);
             fourty.setOnClickListener(view -> {
                 try {
                     showText.setTextSize(40);
                 }catch (Exception e){}

             });
             fifty = findViewById(R.id.fifty);
             fifty.setOnClickListener(view -> {
                 try {
                     showText.setTextSize(50);
                 }catch (Exception e){}

             });
             fiftyfive = findViewById(R.id.fiftyfive);
             fiftyfive.setOnClickListener(view -> {
                 try {
                     showText.setTextSize(55);
                 }catch (Exception e){}

             });
             sixty = findViewById(R.id.sixty);
             sixty.setOnClickListener(view -> {
                 try {
                     showText.setTextSize(60);
                 }catch (Exception e){}

             });
         });
     }
     public void brandSize() {
         brand_size.setOnClickListener(v -> {
             brand_size.setCardBackgroundColor(CYAN);
             text_size.setCardBackgroundColor(WHITE);
             brand_style.setCardBackgroundColor(WHITE);
             text_style.setCardBackgroundColor(WHITE);
             brand_color.setCardBackgroundColor(WHITE);
             text_color.setCardBackgroundColor(WHITE);
             background_color.setCardBackgroundColor(WHITE);

             text_size_layout.setVisibility(View.VISIBLE);
             bgColorLayout.setVisibility(View.INVISIBLE);
             text_color_layout.setVisibility(View.INVISIBLE);
             text_sub_menu.setVisibility(View.GONE);
             fonts_layout.setVisibility(View.INVISIBLE);

             ///////Text Size//////////////
             ///////Text Size//////////////
             eleven = findViewById(R.id.eleven);
             eleven.setOnClickListener(view -> {
                 try {
                     showBrandName.setTextSize(11);
                 }catch (Exception e){}

             });
             thirteen = findViewById(R.id.thirteen);
             thirteen.setOnClickListener(view -> {
                 try {
                     showBrandName.setTextSize(13);
                 }catch (Exception e){}

             });
             fifteen = findViewById(R.id.fifteen);
             fifteen.setOnClickListener(view -> {
                 try {
                     showBrandName.setTextSize(15);
                 }catch (Exception e){}

             });


             seventeen = findViewById(R.id.seventeen);
             seventeen.setOnClickListener(view -> {
                 try {
                     showBrandName.setTextSize(17);
                 }catch (Exception e){}

             });
             nineteen = findViewById(R.id.nineteen);
             nineteen.setOnClickListener(view -> {
                 try {
                     showBrandName.setTextSize(19);
                 }catch (Exception e){}

             });
             twentyone = findViewById(R.id.twentyone);
             twentyone.setOnClickListener(view -> {
                 try {
                     showBrandName.setTextSize(21);
                 }catch (Exception e){}

             });
             twentythree = findViewById(R.id.twentythree);
             twentythree.setOnClickListener(view -> {
                 try {
                     showBrandName.setTextSize(23);
                 }catch (Exception e){}

             });
             twentyfive = findViewById(R.id.twentyfive);
             twentyfive.setOnClickListener(view -> {
                 try {
                     showBrandName.setTextSize(25);
                 }catch (Exception e){}

             });
             twentyseven = findViewById(R.id.twentyseven);
             twentyseven.setOnClickListener(view -> {
                 try {
                     showBrandName.setTextSize(27);
                 }catch (Exception e){}

             });
             twentynine = findViewById(R.id.twentynine);
             twentynine.setOnClickListener(view -> {
                 try {
                     showBrandName.setTextSize(29);
                 }catch (Exception e){}

             });
             thirtyone = findViewById(R.id.thirtyone);
             thirtyone.setOnClickListener(view -> {
                 try {
                     showBrandName.setTextSize(31);
                 }catch (Exception e){}

             });
             thirtythree = findViewById(R.id.thirtythree);
             thirtythree.setOnClickListener(view -> {
                 try {
                     showBrandName.setTextSize(33);
                 }catch (Exception e){}

             });
             thirtyfive = findViewById(R.id.thirtyfive);
             thirtyfive.setOnClickListener(view -> {
                 try {
                     showBrandName.setTextSize(35);
                 }catch (Exception e){}

             });
             fourty = findViewById(R.id.fourty);
             fourty.setOnClickListener(view -> {
                 try {
                     showBrandName.setTextSize(40);
                 }catch (Exception e){}

             });
             fifty = findViewById(R.id.fifty);
             fifty.setOnClickListener(view -> {
                 try {
                     showBrandName.setTextSize(50);
                 }catch (Exception e){}

             });
             fiftyfive = findViewById(R.id.fiftyfive);
             fiftyfive.setOnClickListener(view -> {
                 try {
                     showBrandName.setTextSize(55);
                 }catch (Exception e){}

             });
             sixty = findViewById(R.id.sixty);
             sixty.setOnClickListener(view -> {
                 try {
                     showBrandName.setTextSize(60);
                 }catch (Exception e){}

             });
         });
     }
     public void backgroundColor() {
         background_color.setOnClickListener(v -> {
         background_color.setCardBackgroundColor(CYAN);
             brand_size.setCardBackgroundColor(WHITE);
             text_style.setCardBackgroundColor(WHITE);
             brand_style.setCardBackgroundColor(WHITE);
             text_color.setCardBackgroundColor(WHITE);
                 text_size.setCardBackgroundColor(WHITE);
                 brand_color.setCardBackgroundColor(WHITE);

             bgColorLayout.setVisibility(View.VISIBLE);
             text_color_layout.setVisibility(View.INVISIBLE);
             brand_color_layout.setVisibility(View.INVISIBLE);
             text_sub_menu.setVisibility(View.GONE);
             text_size_layout.setVisibility(View.INVISIBLE);
             fonts_layout.setVisibility(View.INVISIBLE);


             //////background Color/////////
             bg_default = findViewById(R.id.bg_default);
             bg_default.setOnClickListener(view -> {
                 blur.setBackgroundColor(Color.TRANSPARENT);
                 blur_red.setVisibility(View.INVISIBLE);
                 blur_blue.setVisibility(View.INVISIBLE);
                 blur_green.setVisibility(View.INVISIBLE);
                 blur_black.setVisibility(View.INVISIBLE);
                 blur_white.setVisibility(View.INVISIBLE);
                 blur_yellow.setVisibility(View.INVISIBLE);
                 blur_silver.setVisibility(View.INVISIBLE);
                 blur_magenta.setVisibility(View.INVISIBLE);
                 blur_cyan.setVisibility(View.INVISIBLE);
             });
             bg_red = findViewById(R.id.bg_red);
             bg_red.setOnClickListener(view -> {
                 blur_red.setVisibility(View.VISIBLE);
                 blur.setVisibility(View.INVISIBLE);
                 blur_blue.setVisibility(View.INVISIBLE);
                 blur_green.setVisibility(View.INVISIBLE);
                 blur_black.setVisibility(View.INVISIBLE);
                 blur_white.setVisibility(View.INVISIBLE);
                 blur_yellow.setVisibility(View.INVISIBLE);
                 blur_silver.setVisibility(View.INVISIBLE);
                 blur_magenta.setVisibility(View.INVISIBLE);
                 blur_cyan.setVisibility(View.INVISIBLE);


             });
             bg_blue = findViewById(R.id.bg_blue);
             bg_blue.setOnClickListener(view -> {
                 blur_red.setVisibility(View.INVISIBLE);
                 blur.setVisibility(View.INVISIBLE);
                 blur_blue.setVisibility(View.VISIBLE);
                 blur_green.setVisibility(View.INVISIBLE);
                 blur_black.setVisibility(View.INVISIBLE);
                 blur_white.setVisibility(View.INVISIBLE);
                 blur_yellow.setVisibility(View.INVISIBLE);
                 blur_silver.setVisibility(View.INVISIBLE);
                 blur_magenta.setVisibility(View.INVISIBLE);
                 blur_cyan.setVisibility(View.INVISIBLE);

             });
             bg_green = findViewById(R.id.bg_green);
             bg_green.setOnClickListener(view -> {
                 blur_red.setVisibility(View.INVISIBLE);
                 blur.setVisibility(View.INVISIBLE);
                 blur_blue.setVisibility(View.INVISIBLE);
                 blur_green.setVisibility(View.VISIBLE);
                 blur_black.setVisibility(View.INVISIBLE);
                 blur_white.setVisibility(View.INVISIBLE);
                 blur_yellow.setVisibility(View.INVISIBLE);
                 blur_silver.setVisibility(View.INVISIBLE);
                 blur_magenta.setVisibility(View.INVISIBLE);
                 blur_cyan.setVisibility(View.INVISIBLE);
             });
             bg_black = findViewById(R.id.bg_black);
             bg_black.setOnClickListener(view -> {
                 blur_red.setVisibility(View.INVISIBLE);
                 blur.setVisibility(View.INVISIBLE);
                 blur_blue.setVisibility(View.INVISIBLE);
                 blur_green.setVisibility(View.INVISIBLE);
                 blur_black.setVisibility(View.VISIBLE);
                 blur_white.setVisibility(View.INVISIBLE);
                 blur_yellow.setVisibility(View.INVISIBLE);
                 blur_silver.setVisibility(View.INVISIBLE);
                 blur_magenta.setVisibility(View.INVISIBLE);
                 blur_cyan.setVisibility(View.INVISIBLE);
             });
             bg_white = findViewById(R.id.bg_white);
             bg_white.setOnClickListener(view -> {
                 blur_red.setVisibility(View.INVISIBLE);
                 blur.setVisibility(View.INVISIBLE);
                 blur_blue.setVisibility(View.INVISIBLE);
                 blur_green.setVisibility(View.INVISIBLE);
                 blur_black.setVisibility(View.INVISIBLE);
                 blur_white.setVisibility(View.VISIBLE);
                 blur_yellow.setVisibility(View.INVISIBLE);
                 blur_silver.setVisibility(View.INVISIBLE);
                 blur_magenta.setVisibility(View.INVISIBLE);
                 blur_cyan.setVisibility(View.INVISIBLE);
             });
             bg_yellow = findViewById(R.id.bg_yellow);
             bg_yellow.setOnClickListener(view -> {
                 blur_red.setVisibility(View.INVISIBLE);
                 blur.setVisibility(View.INVISIBLE);
                 blur_blue.setVisibility(View.INVISIBLE);
                 blur_green.setVisibility(View.INVISIBLE);
                 blur_black.setVisibility(View.INVISIBLE);
                 blur_white.setVisibility(View.INVISIBLE);
                 blur_yellow.setVisibility(View.VISIBLE);
                 blur_silver.setVisibility(View.INVISIBLE);
                 blur_magenta.setVisibility(View.INVISIBLE);
                 blur_cyan.setVisibility(View.INVISIBLE);
             });
             bg_silver = findViewById(R.id.bg_silver);
             bg_silver.setOnClickListener(view -> {
                 blur_red.setVisibility(View.INVISIBLE);
                 blur.setVisibility(View.INVISIBLE);
                 blur_blue.setVisibility(View.INVISIBLE);
                 blur_green.setVisibility(View.INVISIBLE);
                 blur_black.setVisibility(View.INVISIBLE);
                 blur_white.setVisibility(View.INVISIBLE);
                 blur_yellow.setVisibility(View.INVISIBLE);
                 blur_silver.setVisibility(View.VISIBLE);
                 blur_magenta.setVisibility(View.INVISIBLE);
                 blur_cyan.setVisibility(View.INVISIBLE);
             });
             bg_magenta = findViewById(R.id.bg_magenta);
             bg_magenta.setOnClickListener(view -> {
                 blur_red.setVisibility(View.INVISIBLE);
                 blur.setVisibility(View.INVISIBLE);
                 blur_blue.setVisibility(View.INVISIBLE);
                 blur_green.setVisibility(View.INVISIBLE);
                 blur_black.setVisibility(View.INVISIBLE);
                 blur_white.setVisibility(View.INVISIBLE);
                 blur_yellow.setVisibility(View.INVISIBLE);
                 blur_silver.setVisibility(View.INVISIBLE);
                 blur_magenta.setVisibility(View.VISIBLE);
                 blur_cyan.setVisibility(View.INVISIBLE);
             });
             bg_cyan = findViewById(R.id.bg_cyan);
             bg_cyan.setOnClickListener(view -> {
                 blur_red.setVisibility(View.INVISIBLE);
                 blur.setVisibility(View.INVISIBLE);
                 blur_blue.setVisibility(View.INVISIBLE);
                 blur_green.setVisibility(View.INVISIBLE);
                 blur_black.setVisibility(View.INVISIBLE);
                 blur_white.setVisibility(View.INVISIBLE);
                 blur_yellow.setVisibility(View.INVISIBLE);
                 blur_silver.setVisibility(View.INVISIBLE);
                 blur_magenta.setVisibility(View.INVISIBLE);
                 blur_cyan.setVisibility(View.VISIBLE);
             });
         });
     }
     public void textColor() {
       text_color.setOnClickListener(v -> {
           text_color.setCardBackgroundColor(CYAN);
           brand_style.setCardBackgroundColor(WHITE);
           brand_size.setCardBackgroundColor(WHITE);
           text_style.setCardBackgroundColor(WHITE);
           text_size.setCardBackgroundColor(WHITE);
               brand_color.setCardBackgroundColor(WHITE);
               background_color.setCardBackgroundColor(WHITE);

           text_color_layout.setVisibility(View.VISIBLE);
           brand_color_layout.setVisibility(View.INVISIBLE);
           text_sub_menu.setVisibility(View.GONE);
           bgColorLayout.setVisibility(View.INVISIBLE);
           text_size_layout.setVisibility(View.INVISIBLE);
           fonts_layout.setVisibility(View.INVISIBLE);

           /////////////////Text Color//////////////
           /////////////////Text Color//////////////
           red = findViewById(R.id.red);
           red.setOnClickListener(view -> {
               try {
                   showText.setTextColor(RED);
               }
               catch (Exception e){}

           });
           blue = findViewById(R.id.blue);
           blue.setOnClickListener(view -> {
               try {
                   showText.setTextColor(Color.BLUE);
               }
               catch (Exception e){}

           });
           green = findViewById(R.id.green);
           green.setOnClickListener(view -> {
               try {
                   showText.setTextColor(Color.GREEN);
               }
               catch (Exception e){}

           });
           black = findViewById(R.id.black);
           black.setOnClickListener(view -> {
               try {
                   showText.setTextColor(Color.BLACK);
               }
               catch (Exception e){}

           });
           white = findViewById(R.id.white);
           white.setOnClickListener(view -> {
               try {
                   showText.setTextColor(Color.WHITE);
               }
               catch (Exception e){}

           });
           yellow = findViewById(R.id.yellow);
           yellow.setOnClickListener(view -> {
               try {
                   showText.setTextColor(Color.YELLOW);
               }
               catch (Exception e){}

           });
           silver = findViewById(R.id.silver);
           silver.setOnClickListener(view -> {
               try {
                   showText.setTextColor(Color.GRAY);
               }
               catch (Exception e){}

           });
           magenta = findViewById(R.id.magenta);
           magenta.setOnClickListener(view -> {
               try {
                   showText.setTextColor(Color.MAGENTA);
               }
               catch (Exception e){}

           });
           cyan = findViewById(R.id.cyan);
           cyan.setOnClickListener(view -> {
               try {
                   showText.setTextColor(Color.CYAN);
               }
               catch (Exception e){}

           });
       });

     }
     public void brandColor() {
       brand_color.setOnClickListener(v -> {
           brand_color.setCardBackgroundColor(CYAN);
           brand_size.setCardBackgroundColor(WHITE);
           text_style.setCardBackgroundColor(WHITE);
           text_color.setCardBackgroundColor(WHITE);
           text_size.setCardBackgroundColor(WHITE);
           background_color.setCardBackgroundColor(WHITE);

           brand_color_layout.setVisibility(View.VISIBLE);
           text_color_layout.setVisibility(View.INVISIBLE);
           text_sub_menu.setVisibility(View.GONE);
           add_brandname_layout.setVisibility(View.GONE);
           bgColorLayout.setVisibility(View.INVISIBLE);
           text_size_layout.setVisibility(View.INVISIBLE);
           fonts_layout.setVisibility(View.INVISIBLE);



           /////////////////Text Color//////////////
           /////////////////Text Color//////////////
           red_brand = findViewById(R.id.red_brand);
           red_brand.setOnClickListener(view -> {
               try {
                   showBrandName.setTextColor(RED);
               }
               catch (Exception e){}

           });
           blue_brand = findViewById(R.id.blue_brand);
           blue_brand.setOnClickListener(view -> {
               try {
                   showBrandName.setTextColor(Color.BLUE);
               }
               catch (Exception e){}

           });
           green_brand = findViewById(R.id.green_brand);
           green_brand.setOnClickListener(view -> {
               try {
                   showBrandName.setTextColor(Color.GREEN);
               }
               catch (Exception e){}

           });
           black_brand = findViewById(R.id.black_brand);
           black_brand.setOnClickListener(view -> {
               try {
                   showBrandName.setTextColor(Color.BLACK);
               }
               catch (Exception e){}

           });
           white_brand = findViewById(R.id.white_brand);
           white_brand.setOnClickListener(view -> {
               try {
                   showBrandName.setTextColor(Color.WHITE);
               }
               catch (Exception e){}

           });
           yellow_brand = findViewById(R.id.yellow_brand);
           yellow_brand.setOnClickListener(view -> {
               try {
                   showBrandName.setTextColor(Color.YELLOW);
               }
               catch (Exception e){}

           });
           silver_brand = findViewById(R.id.silver_brand);
           silver_brand.setOnClickListener(view -> {
               try {
                   showBrandName.setTextColor(Color.GRAY);
               }
               catch (Exception e){}

           });
           magenta_brand = findViewById(R.id.magenta_brand);
           magenta_brand.setOnClickListener(view -> {
               try {
                   showBrandName.setTextColor(Color.MAGENTA);
               }
               catch (Exception e){}

           });
           cyan_brand = findViewById(R.id.cyan_brand);
           cyan_brand.setOnClickListener(view -> {
               try {
                   showBrandName.setTextColor(Color.CYAN);
               }
               catch (Exception e){}

           });
       });

     }


     public void addTextButton() {
         addTextButton.setOnClickListener(v -> {
             text_sub_menu.setVisibility(View.GONE);
             showImage.setVisibility(View.VISIBLE);
             inner_layout.setVisibility(View.VISIBLE);
             con2.setVisibility(View.VISIBLE);
             if (editText.getText() == null) {
                 Toast.makeText(this, "Please Enter Text", Toast.LENGTH_SHORT).show();
                 editText.setError("false");
             } else {
                 editText.getText().toString();
                 Toast.makeText(this, "Text Added", Toast.LENGTH_SHORT).show();
                 showText.setText(editText.getText().toString());
             }
         });
     }

     public void addTextButton_brandname() {
         addTextButton_brandname.setOnClickListener(v -> {
             add_brandname_layout.setVisibility(View.GONE);
             showImage.setVisibility(View.VISIBLE);
             inner_layout.setVisibility(View.VISIBLE);

             con2.setVisibility(View.VISIBLE);
             if (editText_brandname.getText() == null) {
                 Toast.makeText(this, "Please Enter Text", Toast.LENGTH_SHORT).show();
                 editText_brandname.setError("false");
             } else {
                 editText_brandname.getText().toString();
                 Toast.makeText(this, "Text Added", Toast.LENGTH_SHORT).show();
                 showBrandName.setText(editText_brandname.getText().toString());
             }
         });
     }

     private void addBrandText() {
         add_brand_text.setOnClickListener(v -> {
             showImage.setVisibility(View.GONE);
             inner_layout.setVisibility(View.GONE);
             con2.setVisibility(View.GONE);
             text_sub_menu.setVisibility(View.GONE);

             add_brandname_layout.setVisibility(View.VISIBLE);
             brand_color_layout.setVisibility(View.INVISIBLE);
             text_color_layout.setVisibility(View.INVISIBLE);
             bgColorLayout.setVisibility(View.INVISIBLE);
             text_size_layout.setVisibility(View.INVISIBLE);
             fonts_layout.setVisibility(View.INVISIBLE);
         });
     }
     public void addText() {
         add_text.setOnClickListener(v -> {
             showImage.setVisibility(View.GONE);
             inner_layout.setVisibility(View.GONE);
             con2.setVisibility(View.GONE);
             text_sub_menu.setVisibility(View.VISIBLE);
             text_color_layout.setVisibility(View.INVISIBLE);
             brand_color_layout.setVisibility(View.INVISIBLE);
             bgColorLayout.setVisibility(View.INVISIBLE);
             text_size_layout.setVisibility(View.INVISIBLE);
             fonts_layout.setVisibility(View.INVISIBLE);

         });
     }

     public void addCircleLogo() {
         circle_logo_click.setOnClickListener(v -> {
             text_sub_menu.setVisibility(View.GONE);
             text_color_layout.setVisibility(View.INVISIBLE);
             bgColorLayout.setVisibility(View.INVISIBLE);
             text_size_layout.setVisibility(View.INVISIBLE);
             brand_color_layout.setVisibility(View.INVISIBLE);

             Intent gallaryIntent=new Intent();
             gallaryIntent.setAction(Intent.ACTION_GET_CONTENT);
             gallaryIntent.setType("image/*");
             startActivityForResult(gallaryIntent,3);
         });
     }

     public void addBackgroundImage() {
         open_gallery.setOnClickListener(v -> {
             text_sub_menu.setVisibility(View.GONE);
             text_color_layout.setVisibility(View.INVISIBLE);
             bgColorLayout.setVisibility(View.INVISIBLE);
             text_size_layout.setVisibility(View.INVISIBLE);
             fonts_layout.setVisibility(View.INVISIBLE);
             brand_color_layout.setVisibility(View.INVISIBLE);

             Intent gallaryIntent = new Intent();
             gallaryIntent.setAction(Intent.ACTION_GET_CONTENT);
             gallaryIntent.setType("image/*");
             startActivityForResult(gallaryIntent, 2);

         });
     }
     ////////// for image show in showimage imageview//////////////////////


     @Override
     protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
         showImage = findViewById(R.id.showImage);
         super.onActivityResult(requestCode, resultCode, data);
         if (requestCode == 2 && resultCode == RESULT_OK && data != null) {
             imageUri = data.getData();
             showImage.setImageURI(imageUri);
             showImage.setVisibility(View.VISIBLE);

         }
         else if (requestCode==3 && resultCode==RESULT_OK && data !=null){
             imageUri2=data.getData();
             circle_logo.setImageURI(imageUri2);
         }
     }
     private Intent rateIntentForUrl(String url) {
         Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(String.format("%s?id=%s", url, getPackageName())));
         int flags = Intent.FLAG_ACTIVITY_NO_HISTORY | Intent.FLAG_ACTIVITY_MULTIPLE_TASK;
         if (Build.VERSION.SDK_INT >= 21)
         {
             flags |= Intent.FLAG_ACTIVITY_NEW_DOCUMENT;
         }
         else
         {
             //noinspection deprecation
             flags |= Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET;
         }
         intent.addFlags(flags);
         return intent;
     }

     private void exitButtonPressed(){
         final Dialog customDialog;
         LayoutInflater inflater = (LayoutInflater) getLayoutInflater();
         View customView = inflater.inflate(R.layout.layout_exit, null);
         customDialog = new Dialog(this, R.style.CustomDialog);
         customDialog.setContentView(customView);
         TextView no = customDialog.findViewById(R.id.tv_no);
         TextView yes = customDialog.findViewById(R.id.tv_yes);

         no.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 try
                 {
                     Intent rateIntent = rateIntentForUrl("market://details");
                     startActivity(rateIntent);
                 }
                 catch (ActivityNotFoundException e)
                 {
                     Intent rateIntent = rateIntentForUrl("https://play.google.com/store/apps/details");
                     startActivity(rateIntent);
                 }
             }
         });

         yes.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 finish();
             }
         });
         customDialog.show();
     }
     @Override
     public void onBackPressed() {
         exitButtonPressed();
     }
 }