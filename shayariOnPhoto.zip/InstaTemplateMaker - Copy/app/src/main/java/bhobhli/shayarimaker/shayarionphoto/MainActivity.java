package bhobhli.shayarimaker.shayarionphoto;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ImageView;
import android.widget.Toast;


import de.hdodenhof.circleimageview.CircleImageView;
import pl.droidsonroids.gif.GifImageView;

public class MainActivity extends AppCompatActivity {
    ConstraintLayout con1,con2,con3,con4,con5,con6,con7,con8,con9,con10,con11,con12;
    GifImageView openQurekaGif;
    boolean doubleBackToExitPressedOnce = false;
    CircleImageView share_app;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        openQurekaGif=findViewById(R.id.open_qureka);
        share_app=findViewById(R.id.share_app);
        openQurekaGif.setOnClickListener(v -> {
        exit();
        });

        share_app.setOnClickListener(v -> {
            final String appLink = "\nhttps://play.google.com/store/apps/details?id=" + getPackageName();
            Intent sendInt = new Intent(Intent.ACTION_SEND);
            sendInt.putExtra(Intent.EXTRA_SUBJECT, getString(R.string.app_name));
            sendInt.putExtra(Intent.EXTRA_TEXT, getString(R.string.share_app_message) + appLink);
            sendInt.setType("text/plain");
            startActivity(Intent.createChooser(sendInt, "Share"));        });
        con1=findViewById(R.id.c1);
        con2=findViewById(R.id.c2);
        con3=findViewById(R.id.c3);
        con4=findViewById(R.id.c4);
        con5=findViewById(R.id.c5);
        con6=findViewById(R.id.c6);
        con7=findViewById(R.id.c7);
        con8=findViewById(R.id.c8);
        con9=findViewById(R.id.c9);
        con10=findViewById(R.id.c10);
        con11=findViewById(R.id.c11);
        con12=findViewById(R.id.c12);

        con1.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this,First.class));
        });
        con2.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this,Second.class));
        });
        con3.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this,Third.class));
        });
        con4.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this,Fourth.class));
        });
        con5.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this,Fifth.class));
        });
        con6.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this,Sixth.class));
        });
        con7.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this,Seventh.class));
        });
        con8.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this,Eighth.class));
        });
        con9.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this,Ninth.class));
        });
        con10.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this,Tenth.class));
        });
        con11.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this,Eleventh.class));
        });
        con12.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this,Twelve.class));
        });

    }

    private  void exit(){
        if (doubleBackToExitPressedOnce) {
            finish();
        }
        this.doubleBackToExitPressedOnce = true;
        Toast.makeText(getApplicationContext(),
                R.string.please_back,
                Toast.LENGTH_SHORT).show();
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                doubleBackToExitPressedOnce = false;
            }
        }, 250);
    }
    @Override
    public void onBackPressed() {
    exit();
    }
}